<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 5/20/22
 * Time: 1:54 AM
 */

require_once('app/sfs_controller.php');
$Call=new sfs_controller();

if(isset($_REQUEST['Submit'])=="FormData")
{
    $DataArray=$_REQUEST;
    $Call->form_data($DataArray);

}
elseif(isset($_REQUEST['page'])=="report")
{
   $Call->report();
}
else
{
    $Call->home();
}






