<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 5/20/22
 * Time: 1:54 AM
 */

class sfs_model
{
    public function data_check($buyer_ip,$date)
    {
        $conn =$this->db_connect();

        $sql = "SELECT buyer_ip, entry_at FROM submission_data where entry_at='$date' AND buyer_ip='$buyer_ip'";
        $result = $conn->query($sql);
        $rowcount=$result->num_rows;
        return $rowcount;
    }

    public function insert_form_data($amount,$buyer,$receipt,$receipt_hash,$email,$city,$entry,$phone,$note,$items_value,$buyer_ip,$date)
    {
        $conn =$this->db_connect();
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "INSERT INTO submission_data (amount,buyer,receipt_id,items,buyer_email,buyer_ip,note,city,phone,hash_key,entry_at,entry_by)
VALUES ('$amount','$buyer','$receipt','$items_value','$email','$buyer_ip','$note','$city','$phone','$receipt_hash','$date','$entry')";

        if ($conn->query($sql) === TRUE)
        {
            echo 'New record created successfully';
        }
        else
        {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }

    public function form_data()
    {
        $conn = $this->db_connect();
        $sql = "select * from submission_data";
        $result = $conn->query($sql);
        $data_response = array();
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
        {
            $row_array['id'] = $row['id'];
            $row_array['amount'] = $row['amount'];
            $row_array['buyer'] = $row['buyer'];
            $row_array['receipt_id'] = $row['receipt_id'];
            $row_array['buyer_email'] = $row['buyer_email'];
            $row_array['items'] = $row['items'];
            $row_array['entry_at'] = $row['entry_at'];

            array_push($data_response,$row_array);
        }
        return $data_response;
    }

   public function db_connect()
   {
       $conn = mysqli_connect("localhost","root","","sfs");
       if ($conn->connect_error) {
           die("Connection failed: " . $conn->connect_error);
       }
       return $conn;

   }

} 