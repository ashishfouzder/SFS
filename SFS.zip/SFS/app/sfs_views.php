<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 5/20/22
 * Time: 1:55 AM
 */

class sfs_views
{

    public function HomePage()
    {
        require_once('ui/form.php');
    }
    public function ReportPage($FormData)
    {
        require_once('ui/report.php');
    }

} 