<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>SFS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Simple PHP form submission script with frontend validation " name="description" />
    <meta content="xpeedstudio" name="Kamonashish Fuzder" />
    <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="assets/css/preloader.min.css" type="text/css" />
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

</head>

<body>

<!-- <body data-layout="horizontal"> -->

<!-- Begin page -->
<div id="layout-wrapper">


<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <a href="#" class="logo logo-dark">
           <span class="logo-sm">
                 <img src="assets/images/xpeedstudio.png" alt="" height="24">
           </span>
           <span class="logo-lg">
                 <img src="assets/images/xpeedstudio.png" alt="" height="24"> <span class="logo-txt">XpeedStudio</span>
           </span>
                </a>

                <a href="#" class="logo logo-light">
          <span class="logo-sm">
                <img src="assets/images/xpeedstudio.png" alt="" height="24">
          </span>
          <span class="logo-lg">
                <img src="assets/images/xpeedstudio.png" alt="" height="24"> <span class="logo-txt">XpeedStudio</span>
          </span>
                </a>
            </div>
            <button type="button" class="btn btn-sm px-3 font-size-16 header-item" id="vertical-menu-btn">
                <i class="fa fa-fw fa-bars"></i>
            </button>
        </div>

        <div class="d-flex">

        </div>
    </div>
</header>

<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" data-key="t-menu">Menu</li>
                <li>
                    <a href="index.php">
                        <i class="bx bx-home"></i>
                        <span data-key="t-dashboard">Home</span>
                    </a>
                </li>
                <li>
                    <a href="index.php?page=report">
                        <i class="bx bx-receipt"></i>
                        <span data-key="t-report">Report</span>
                    </a>
                </li>
            </ul>
            <br><br><br>
            <div class="card sidebar-alert border-0 text-center mx-4 mb-0 mt-5">
                <div class="card-body">
                    <img src="assets/images/giftbox.png" alt="">
                    <div class="mt-4">
                        <a href="#" class="btn btn-primary mt-2">Send Data</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

<div class="page-content">
<div class="container-fluid">

<div class="row">
<div class="col-12">
<div class="card">
<div class="card-header">
    <h4 class="card-title">Report</h4>
</div>
<div class="card-body">

<table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
<thead>
<tr>
    <th>Id</th>
    <th>Amount</th>
    <th>Buyer</th>
    <th>Receipt Id</th>
    <th>Items</th>
    <th>Email</th>
    <th>Date</th>
</tr>
</thead>


<tbody>
  <?php
     foreach($FormData as $FormDataValue)
     {
  ?>

<tr>
    <td><?php echo $FormDataValue['id'] ?></td>
    <td><?php echo $FormDataValue['amount'] ?></td>
    <td><?php echo $FormDataValue['buyer'] ?></td>
    <td><?php echo $FormDataValue['receipt_id'] ?></td>
    <td><?php echo $FormDataValue['items'] ?></td>
    <td><?php echo $FormDataValue['buyer_email'] ?></td>
    <td><?php echo $FormDataValue['entry_at'] ?></td>
</tr>

<?php } ?>

</tbody>
</table>

</div>
</div>
</div> <!-- end col -->
</div> <!-- end row -->

</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                &nbsp;&nbsp; <script>document.write(new Date().getFullYear())</script> © XpeedStudio.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <a href="http://fouzder.com/" target="_blank" class="text-decoration-underline">Kamonashish Fouzder</a>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->

<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- JAVASCRIPT -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/feather-icons/feather.min.js"></script>
<script src="assets/libs/pace-js/pace.min.js"></script>
<script src="assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="assets/libs/jszip/jszip.min.js"></script>
<script src="assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="assets/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<script src="assets/js/pages/datatables.init.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
