<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>SFS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Simple PHP form submission script with frontend validation " name="description" />
    <meta content="xpeedstudio" name="Kamonashish Fuzder" />
    <link rel="stylesheet" href="assets/css/preloader.min.css" type="text/css" />
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="assets/css/external.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="assets/css/intlTelInput.css" id="app-style" rel="stylesheet" type="text/css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!--AJAX-->
    <script>
        $(document).ready(function() {
            <!--#my-form grabs the form id-->
            $("#pristine-valid-example").submit(function(e) {
                e.preventDefault();
                $.ajax( {
                    url: "index.php",
                    method: "post",
                    data: $("form").serialize(),
                    dataType: "text",
                    success: function(strMessage) {
                        $("#message").text(strMessage);
                        $("#my-form")[0].reset();
                    }
                });
            });
        });
    </script>
    <script>
        function limitWords(id) {
            var maxWords=31;
            var d=document.getElementById(id);
            if ( d.value.split(' ').length > maxWords ) {
                t=d.value.substring(0,d.value.lastIndexOf(' '));
                d.value=t.substring(0,t.lastIndexOf(' ')+1);
            }
        }
    </script>
</head>
<body>
<!-- <body data-layout="horizontal"> -->
<!-- Begin page -->
<div id="layout-wrapper">

<header id="page-topbar">
<div class="navbar-header">
<div class="d-flex">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="#" class="logo logo-dark">
           <span class="logo-sm">
                 <img src="assets/images/xpeedstudio.png" alt="" height="24">
           </span>
           <span class="logo-lg">
                 <img src="assets/images/xpeedstudio.png" alt="" height="24"> <span class="logo-txt">XpeedStudio</span>
           </span>
        </a>

        <a href="#" class="logo logo-light">
          <span class="logo-sm">
                <img src="assets/images/xpeedstudio.png" alt="" height="24">
          </span>
          <span class="logo-lg">
                <img src="assets/images/xpeedstudio.png" alt="" height="24"> <span class="logo-txt">XpeedStudio</span>
          </span>
        </a>
    </div>
    <button type="button" class="btn btn-sm px-3 font-size-16 header-item" id="vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>
</div>

<div class="d-flex">

</div>
</div>
</header>

<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">
<div data-simplebar class="h-100">
<!--- Sidemenu -->
<div id="sidebar-menu">
<!-- Left Menu Start -->
<ul class="metismenu list-unstyled" id="side-menu">
<li class="menu-title" data-key="t-menu">Menu</li>
    <li>
        <a href="index.php">
            <i class="bx bx-home"></i>
            <span data-key="t-dashboard">Home</span>
        </a>
    </li>
    <li>
        <a href="index.php?page=report">
            <i class="bx bx-receipt"></i>
            <span data-key="t-report">Report</span>
        </a>
    </li>
</ul>
<br><br><br>
<div class="card sidebar-alert border-0 text-center mx-4 mb-0 mt-5">
    <div class="card-body">
        <img src="assets/images/giftbox.png" alt="">
        <div class="mt-4">
            <a href="#" class="btn btn-primary mt-2">Send Data</a>
        </div>
    </div>
</div>
</div>
<!-- Sidebar -->
</div>
</div>
<!-- Left Sidebar End -->



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

<div class="page-content">
<div class="container-fluid">

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">SFS Data submission</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                    <li class="breadcrumb-item active">Submission</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

    <p id="message"></p>

    <div class="card-body">
        <div>
            <form id="pristine-valid-example" novalidate method="post" enctype="multipart/form-data">
                <input type="hidden"/>
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Amount [ number only ]</label>
                            <input type="number" id="amount" name="amount" min="1" data-pristine-min-message="Enter amount" required class="form-control"  placeholder="Enter amount"/>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Buyer</label>
                            <input type="text" name="buyer" id="buyer" required data-pristine-required-message="Please Enter Buyer Name"  maxlength="20" class="form-control" placeholder="Buyer name" />
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Receipt ID [ number only ]</label>
                            <input type="text" name="receipt" id="Receipt" required data-pristine-required-message="Please Enter Receipt Id ( only text allowed )"  maxlength="20" class="form-control" pattern="[A-Za-z]+" placeholder="Receipt ID" />
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Email</label>
                            <input type="email" name="email" id="email" required data-pristine-required-message="Please Enter a Email" class="form-control" placeholder="Enter your Email" />
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>City</label>
                            <input type="text" name="city" id="City" required data-pristine-required-message="Please Enter City Name"  maxlength="20" class="form-control" pattern="[A-Za-z]+" placeholder="City name" />
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Entry by [ number only ]</label>
                            <input type="number" id="entry" name="entry" maxlength="10" data-pristine-min-message="only number allowed" required class="form-control"  placeholder="Entry number"/>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Phone</label><br>
                            <input type="tel" name="phone" id="txtPhone" class="form-control" placeholder="Phone number" required />
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Note</label>
                            <textarea id='txt' name="note" rows="1" onkeyup="limitWords(this.id)" class="form-control" required></textarea>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="form-group mb-3">
                            <label>Items</label>
                            <input type="text" name="Items[]" id="Items" required data-pristine-required-message="only text allowed"  class="form-control" maxlength="20"  pattern="[A-Za-z]+" placeholder="Items name" />
                        </div>

                        <table id="cloned_items">
                            <tr>
                                <td><div id='cloned'></div></td>
                            </tr>
                        </table>
                        <button type="button" id='bt' class="btn btn-primary">
                            <i class="fa fa-plus" aria-hidden="true">&nbsp;Item</i>
                        </button>
                    </div>

                </div>
                <!-- end row -->
                <br>
                <div class="form-group">
                    <input type="hidden" name="Submit" value="FormData">
                    <button type="submit" class="btn btn-success waves-effect waves-light">SUBMIT DATA</button>
                </div>
            </form>
        </div>
    </div>


</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
               &nbsp;&nbsp; <script>document.write(new Date().getFullYear())</script> © XpeedStudio.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <a href="http://fouzder.com/" target="_blank" class="text-decoration-underline">Kamonashish Fouzder</a>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->




<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- JAVASCRIPT -->
<!--<script src="assets/libs/jquery/jquery.min.js"></script>-->
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/feather-icons/feather.min.js"></script>
<script src="assets/libs/pace-js/pace.min.js"></script>
<script src="assets/libs/pristinejs/pristine.min.js"></script>
<script src="assets/js/pages/form-validation.init.js"></script>
<script src="assets/js/app.js"></script>
<script>
    $("#Receipt").on('keyup', function(e) {
        var val = $(this).val();
        if (val.match(/[^a-zA-Z]/g)) {
            $(this).val(val.replace(/[^a-zA-Z]/g, ''));
        }
    });

    $("#City").on('keyup', function(e) {
        var val = $(this).val();
        if (val.match(/[^a-zA-Z]/g)) {
            $(this).val(val.replace(/[^a-zA-Z]/g, ''));
        }
    });
    $("#Items").on('keyup', function(e) {
        var val = $(this).val();
        if (val.match(/[^a-zA-Z]/g)) {
            $(this).val(val.replace(/[^a-zA-Z]/g, ''));
        }
    });

    $(document).ready(function () {
        $('#bt').on('click', function () {
            $('#Items')
                // clone(true,true) means -> .clone( [withDataAndEvents ] [, deepWithDataAndEvents ] )
                .clone(true, true)
                .attr('id', 'cloned_t')
                .appendTo('#cloned');
        });
    });
</script>




<script>
    $(function() {
        var $componentTB = $("#component_tb"),
            $firstTRCopy = $("#row0").clone();
        $idVal = 1;
        $("#addRows").click(function() {
            var copy = $firstTRCopy.clone();
            var newId = 'row' +$idVal;
            copy.attr('id', newId);
            $idVal += 1;
            copy.children('td').last().append("<a href=\"javascript:remove('" + newId + "')\">Remove</a>");
            $componentTB.append(copy);
        });
    });
    function remove(id){
        $("#" + id).remove();
    }
</script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/js/intlTelInput-jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        var code = "+880"; // Assigning value from model.
        $('#txtPhone').val(code);
        $('#txtPhone').intlTelInput({
            autoHideDialCode: true,
            autoPlaceholder: "ON",
            dropdownContainer: document.body,
            formatOnDisplay: true,
            hiddenInput: "full_number",
            initialCountry: "auto",
            nationalMode: true,
            placeholderNumberType: "MOBILE",
            preferredCountries: ['US'],
            separateDialCode: true
        });
        $('#btnSubmit').on('click', function () {
            var code = $("#txtPhone").intlTelInput("getSelectedCountryData").dialCode;
            var phoneNumber = $('#txtPhone').val();
            var name = $("#txtPhone").intlTelInput("getSelectedCountryData").name;
            alert('Country Code : ' + code + '\nPhone Number : ' + phoneNumber + '\nCountry Name : ' + name);
        });
    });
</script>

</body>
</html>
