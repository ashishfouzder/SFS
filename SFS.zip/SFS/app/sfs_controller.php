<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 5/20/22
 * Time: 1:55 AM
 */
class sfs_controller
{

    public function home()
    {
        $UI=$this->Views();
        $UI->HomePage();
    }
    public function report()
    {
        $DbModel=$this->Model();
        $FormData=$DbModel->form_data();
        $UI=$this->Views();
        $UI->ReportPage($FormData);
    }
    public function form_data($DataArray)
    {
        //print_r($DataArray);
        $amount=$DataArray['amount'];
        $buyer=$DataArray['buyer'];
        $receipt=$DataArray['receipt'];
        $receipt_hash=hash('sha512', $receipt);
       // $ReceiptShort=substr($receipt_hash,0,20);
        $email=$DataArray['email'];
        $city=$DataArray['city'];
        $entry=$DataArray['entry'];
        $phone=$DataArray['phone'];
        $note=$DataArray['note'];
        $Items=$DataArray['Items'];
        $ItemsDataValue=array();
        foreach($Items as $ItemsData)
        {
            $ItemsDataValue[]= $ItemsData.",";
        }
        $items_value=implode(" ",$ItemsDataValue);
        $buyer_ip=$this->client_browser_ip();
        $dt = new DateTime('now', new DateTimezone('Asia/Dhaka'));
        $date=$dt->format('Y-m-d');

        if($amount==0)
        {
            echo "Please type a amount";
        }
        elseif($buyer=='')
        {
            echo "Please type a buyer name";
        }
        elseif($receipt=='')
        {
            echo "Please type a Receipt ID";
        }
        elseif($email=='')
        {
            echo "Please type a Email ID";
        }
        elseif($city=='')
        {
            echo "Please type a City Name";
        }
        elseif($entry=='')
        {
            echo "Please type a Entry Number";
        }
        elseif($phone=='')
        {
            echo "Please type a Phone Number";
        }
        elseif($note=='')
        {
            echo "Please type a note";
        }
        else
        {
            $DbModel=$this->Model();
            $DataCheck=$DbModel->data_check($buyer_ip,$date);
            if($DataCheck==1)
            {
                echo "Buyer data already exists try again 24 hours later";
            }
            else
            {
                $DbModel->insert_form_data($amount,$buyer,$receipt,$receipt_hash,$email,$city,$entry,$phone,$note,$items_value,$buyer_ip,$date);
            }
        }
    }

    public function client_browser_ip()
    {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
            $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
    public function Views()
    {
        require_once('sfs_views.php');
        $Views=new sfs_views();
        return $Views;
    }
    public function Model()
    {
        require_once('sfs_model.php');
        $Model= new sfs_model();
        return $Model;
    }

} 